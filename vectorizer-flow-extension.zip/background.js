// Passive Web Request Listener to capture OAuth Bearer tokens automatically
let memoryBearerToken = null;
let memoryBearerTokenTime = 0;

function detectMimeFromBase64(b64) {
  if (!b64 || typeof b64 !== 'string') return null;
  const clean = b64.replace(/^data:[^,]+,/, '').trim();
  if (clean.startsWith('iVBORw0KGgo')) return 'image/png';
  if (clean.startsWith('/9j/')) return 'image/jpeg';
  if (clean.startsWith('UklGR')) return 'image/webp';
  if (clean.startsWith('R0lGOD')) return 'image/gif';
  if (clean.startsWith('PHN2Zy') || clean.startsWith('PD94bWw')) return 'image/svg+xml';
  return null;
}

function normalizeDataUrl(input, fallbackMime = 'image/png') {
  if (!input || typeof input !== 'string') return '';
  const str = input.trim();
  if (str.startsWith('data:')) {
    const commaIdx = str.indexOf(',');
    if (commaIdx !== -1) {
      const b64Data = str.substring(commaIdx + 1);
      const detected = detectMimeFromBase64(b64Data);
      if (detected) {
        return `data:${detected};base64,${b64Data}`;
      }
      return str;
    }
    return str;
  }
  const detected = detectMimeFromBase64(str) || fallbackMime;
  return `data:${detected};base64,${str}`;
}

if (typeof chrome !== 'undefined' && chrome.webRequest && chrome.webRequest.onBeforeSendHeaders) {
  try {
    chrome.webRequest.onBeforeSendHeaders.addListener(
      (details) => {
        if (!details.requestHeaders) return;
        for (const h of details.requestHeaders) {
          if (h.name && h.name.toLowerCase() === 'authorization') {
            const val = h.value || '';
            if (val.startsWith('Bearer ya29.') || val.startsWith('ya29.')) {
              const token = val.replace(/^Bearer\s+/i, '').trim();
              if (token.startsWith('ya29.') && token.length > 30) {
                memoryBearerToken = token;
                memoryBearerTokenTime = Date.now();
                if (chrome.storage && chrome.storage.local) {
                  chrome.storage.local.set({ captured_bearer_token: token, captured_bearer_time: Date.now() });
                }
              }
            }
          }
        }
      },
      { urls: ["*://aisandbox-pa.googleapis.com/*", "*://flow.google.com/*", "*://*.flow.google.com/*", "*://labs.google/*", "*://*.labs.google/*"] },
      ["requestHeaders", "extraHeaders"]
    );
  } catch (e) {
    console.warn('[background] webRequest listener setup error:', e);
  }
}

async function getStoredBearerToken() {
  if (memoryBearerToken && (Date.now() - memoryBearerTokenTime < 3600000)) {
    return memoryBearerToken;
  }
  return new Promise((resolve) => {
    try {
      if (chrome.storage && chrome.storage.local) {
        chrome.storage.local.get(['captured_bearer_token', 'captured_bearer_time'], (res) => {
          if (res && res.captured_bearer_token && res.captured_bearer_time && (Date.now() - res.captured_bearer_time < 3600000)) {
            memoryBearerToken = res.captured_bearer_token;
            memoryBearerTokenTime = res.captured_bearer_time;
            resolve(res.captured_bearer_token);
          } else if (res && res.captured_bearer_token) {
            resolve(res.captured_bearer_token);
          } else {
            resolve(null);
          }
        });
      } else {
        resolve(null);
      }
    } catch (e) {
      resolve(null);
    }
  });
}

function findFlowTab(preferredProjectId = null) {
  return new Promise((resolve) => {
    try {
      chrome.tabs.query({}, (tabs) => {
        if (!tabs || !tabs.length) {
          resolve(null);
          return;
        }

        const flowTabs = tabs.filter(t => {
          if (!t.url) return false;
          const u = t.url.toLowerCase();
          // Exclude web app tabs
          if (u.includes('gravitylab') || u.includes('localhost') || u.includes('127.0.0.1') || u.includes('vercel.app')) {
            return false;
          }
          return u.includes('flow.google.com') ||
                 u.includes('flow.google') ||
                 u.includes('labs.google/fx/tools/flow') ||
                 u.includes('labs.google.com/fx/tools/flow') ||
                 u.includes('labs.google/fx/tools') ||
                 u.includes('labs.google/flow') ||
                 (u.includes('labs.google') && u.includes('flow'));
        });

        if (flowTabs.length === 0) {
          resolve(null);
          return;
        }

        // Preference 1: Match tab URL containing preferredProjectId
        if (preferredProjectId) {
          const matchProj = flowTabs.find(t => t.url.includes(preferredProjectId));
          if (matchProj) {
            resolve(matchProj);
            return;
          }
        }

        // Preference 2: Tab containing /project/ in URL
        const matchWithProject = flowTabs.find(t => /\/project[\/=]/i.test(t.url));
        if (matchWithProject) {
          resolve(matchWithProject);
          return;
        }

        // Preference 3: Active tab or first available tab
        const activeTab = flowTabs.find(t => t.active);
        resolve(activeTab || flowTabs[0]);
      });
    } catch (e) {
      resolve(null);
    }
  });
}

// External message listener (from web app)
chrome.runtime.onMessageExternal.addListener((request, sender, sendResponse) => {
  console.log('[background] Received external message:', request, 'from:', sender);

  if (request.action === 'ping') {
    findFlowTab().then((tab) => {
      sendResponse({ ok: true, status: 'active', extensionType: 'saas_direct', version: '1.1.0', tabOpen: !!tab });
    });
    return true;
  }

  if (request.action === 'generate') {
    handleGenerateFlow(request, sendResponse);
    return true; // Keep channel open for async response
  }

  sendResponse({ ok: false, error: 'Unknown action: ' + request.action });
  return false;
});

// Also listen to internal runtime messages (bridged from content/bridge.js & content.js heartbeat)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request && request.action === 'GENERATION_HEARTBEAT') {
    sendResponse({ ok: true, active: true, time: Date.now() });
    return false;
  }
  if (request && request.action === 'generate' && sender.tab) {
    handleGenerateFlow(request, sendResponse);
    return true;
  }
});

async function getDirectSessionToken() {
  const sessionUrls = [
    'https://labs.google/fx/api/auth/session',
    'https://flow.google.com/api/auth/session',
    'https://labs.google/api/auth/session',
    'https://flow.google.com/fx/api/auth/session'
  ];
  for (const u of sessionUrls) {
    try {
      const resp = await fetch(u, { credentials: 'include' });
      if (resp.ok) {
        const text = await resp.text();
        if (text && text.includes('ya29.')) {
          const m = text.match(/ya29\.[A-Za-z0-9_-]{30,}/);
          if (m) return m[0];
        }
        try {
          const data = JSON.parse(text);
          const tok = data.access_token || data.accessToken || data.token || data.idToken || data.id_token || data.user?.access_token || data.user?.accessToken;
          if (tok) return tok;
        } catch (_) {}
      }
    } catch (_) {}
  }
  return null;
}

async function handleGenerateFlow(request, sendResponse) {
  try {
    const reqProjectId = request.projectId || (request.url && request.url.match(/project[\\/=]([0-9a-f-]{36})/i) ? request.url.match(/project[\\/=]([0-9a-f-]{36})/i)[1] : null);
    
    // Locate any open Google Flow tab or auto-open if missing
    let targetTab = await findFlowTab(reqProjectId);
    if (!targetTab) {
      console.log('[background] Google Flow tab not open. Auto-opening Google Flow...');
      const targetUrl = reqProjectId ? `https://flow.google.com/project/${reqProjectId}` : "https://flow.google.com/";
      targetTab = await new Promise((resolve) => {
        chrome.tabs.create({ url: targetUrl, active: true }, (newTab) => {
          setTimeout(() => resolve(newTab), 4000);
        });
      });
    }

    if (!targetTab) {
      sendResponse({ ok: false, error: 'Could not open or locate Google Flow tab.' });
      return;
    }

    // Execute session extraction & reCAPTCHA in MAIN world of target tab (Main frame only)
    let executionResult = null;
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: targetTab.id },
        world: 'MAIN',
        func: async () => {
          return new Promise(async (resolve) => {
            let done = false;

            const safeJson = async (url) => {
              try {
                const r = await fetch(url, { credentials: 'include', headers: { 'Accept': 'application/json' } });
                if (!r || !r.ok) return null;
                const ct = (r.headers && r.headers.get('content-type')) || '';
                if (!ct.includes('json')) {
                  const t = await r.text();
                  if (t && (t.startsWith('{') || t.startsWith('['))) return JSON.parse(t);
                  return null;
                }
                return await r.json();
              } catch (e) { return null; }
            };

            const getSessionToken = async () => {
              // 0. Check window.__CAPTURED_BEARER_TOKEN__ & storage
              try {
                if (window.__CAPTURED_BEARER_TOKEN__) return window.__CAPTURED_BEARER_TOKEN__;
                const st = localStorage.getItem('__gflow_bearer_token') || sessionStorage.getItem('__gflow_bearer_token');
                if (st && st.length > 20) return st;
              } catch (_) {}

              // 1. Check window global properties
              try {
                for (const k of Object.keys(window)) {
                  try {
                    const val = window[k];
                    if (typeof val === 'string' && val.includes('ya29.')) {
                      const m = val.match(/ya29\.[A-Za-z0-9_-]{30,}/);
                      if (m) return m[0];
                    }
                  } catch (_) {}
                }
              } catch (_) {}

              // 2. ya29 OAuth token in scripts
              try {
                for (const s of document.querySelectorAll('script')) {
                  if (s.textContent && s.textContent.includes('ya29.')) {
                    const m = s.textContent.match(/ya29\.[A-Za-z0-9_-]{30,}/);
                    if (m && m[0]) return m[0];
                  }
                }
              } catch (e) {}

              // 3. Fetch auth session endpoints
              const eps = [
                'https://flow.google.com/api/auth/session',
                'https://labs.google/fx/api/auth/session',
                '/api/auth/session',
                '/fx/api/auth/session',
                '/api/session'
              ];
              for (const ep of eps) {
                const data = await safeJson(ep);
                if (data) {
                  const tok = data.access_token || data.accessToken || data.token || data.idToken || data.id_token || data.user?.access_token || data.user?.accessToken;
                  if (tok) return tok;
                }
              }

              // 4. Check __NEXT_DATA__
              try {
                const s = document.getElementById('__NEXT_DATA__');
                if (s && s.textContent) {
                  const m = s.textContent.match(/ya29\.[A-Za-z0-9_-]{30,}/);
                  if (m && m[0]) return m[0];
                }
              } catch (e) {}

              // 5. Check localStorage / sessionStorage / cookies
              try {
                const stores = [localStorage, sessionStorage];
                for (const st of stores) {
                  if (!st) continue;
                  for (let i = 0; i < st.length; i++) {
                    const k = st.key(i) || '';
                    const v = st.getItem(k);
                    if (v && typeof v === 'string') {
                      const m = v.match(/ya29\.[A-Za-z0-9_-]{30,}/);
                      if (m && m[0]) return m[0];
                    }
                  }
                }
                if (document.cookie) {
                  const m = document.cookie.match(/ya29\.[A-Za-z0-9_-]{30,}/);
                  if (m && m[0]) return m[0];
                }
              } catch (e) {}

              // 6. Check IndexedDB
              try {
                if (window.indexedDB && window.indexedDB.databases) {
                  const dbs = await window.indexedDB.databases();
                  for (const dbInfo of dbs) {
                    if (dbInfo.name && (dbInfo.name.includes('firebase') || dbInfo.name.includes('auth') || dbInfo.name.includes('flow') || dbInfo.name.includes('google') || dbInfo.name.includes('idb'))) {
                      const req = window.indexedDB.open(dbInfo.name);
                      const tok = await new Promise((res) => {
                        req.onsuccess = () => {
                          const db = req.result;
                          for (const storeName of db.objectStoreNames) {
                            try {
                              const tx = db.transaction(storeName, 'readonly');
                              const store = tx.objectStore(storeName);
                              const getAllReq = store.getAll();
                              getAllReq.onsuccess = () => {
                                const items = getAllReq.result || [];
                                for (const it of items) {
                                  const str = JSON.stringify(it);
                                  const m = str.match(/ya29\.[A-Za-z0-9_-]{30,}/);
                                  if (m) { res(m[0]); return; }
                                }
                                res(null);
                              };
                              getAllReq.onerror = () => res(null);
                            } catch (_) { res(null); }
                          }
                        };
                        req.onerror = () => res(null);
                      });
                      if (tok) return tok;
                    }
                  }
                }
              } catch (_) {}

              return null;
            };

            const getProjectId = () => {
              const findUuid = (str) => {
                const m = str && str.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
                return m ? m[0] : null;
              };
              const pm = location.href.match(/project[\\/=]([0-9a-f-]{36})/i);
              if (pm) return pm[1];
              try {
                const links = document.querySelectorAll('a[href*="/project/"], a[href*="project="], a[href*="/tools/flow/"]');
                for (const a of links) {
                  const u = findUuid(a.href || a.getAttribute('href') || '');
                  if (u) return u;
                }
              } catch (e) {}
              try {
                const s = document.getElementById('__NEXT_DATA__');
                if (s && s.textContent) {
                  const mm = s.textContent.match(/"projectId"\s*:\s*"([0-9a-f-]{36})"/i) ||
                             s.textContent.match(/"id"\s*:\s*"([0-9a-f-]{36})"/i);
                  if (mm) return mm[1];
                }
              } catch (e) {}
              try {
                const lastPid = localStorage.getItem('last_flow_project_id');
                if (lastPid && findUuid(lastPid)) return findUuid(lastPid);
              } catch (e) {}
              return findUuid(location.href);
            };

            const sessionToken = await getSessionToken();
            const projectId = getProjectId();

            const timer = setTimeout(() => {
              if (!done) {
                done = true;
                resolve({ ok: true, token: 'DEFAULT_RECAPTCHA_TOKEN', sessionToken, projectId });
              }
            }, 6000);

            const getSiteKey = () => {
              let siteKey = '6LdsFiUsAAAAAIjVDZcuLhaHiDn5nnHVXVRQGeMV';
              try {
                const scripts = document.querySelectorAll('script[src*="recaptcha"]');
                for (const script of scripts) {
                  const match = script.src.match(/render=([A-Za-z0-9_-]+)/);
                  if (match && match[1]) {
                    siteKey = match[1];
                    break;
                  }
                }
              } catch (_) {}
              return siteKey;
            };

            const executeCall = (siteKey) => {
              return grecaptcha.enterprise.execute(siteKey, { action: 'IMAGE_GENERATION' })
                .then(t => {
                  if (done) return;
                  done = true;
                  clearTimeout(timer);
                  resolve({ ok: true, token: t, sessionToken, projectId });
                })
                .catch(() => {
                  if (done) return;
                  done = true;
                  clearTimeout(timer);
                  resolve({ ok: true, token: 'DEFAULT_RECAPTCHA_TOKEN', sessionToken, projectId });
                });
            };

            if (typeof grecaptcha !== 'undefined' && grecaptcha.enterprise) {
              const siteKey = getSiteKey();
              try {
                executeCall(siteKey).catch(() => {});
              } catch (e) {
                if (!done) {
                  done = true;
                  clearTimeout(timer);
                  resolve({ ok: true, token: 'DEFAULT_RECAPTCHA_TOKEN', sessionToken, projectId });
                }
              }
            } else {
              if (!done) {
                done = true;
                clearTimeout(timer);
                resolve({ ok: true, token: 'DEFAULT_RECAPTCHA_TOKEN', sessionToken, projectId });
              }
            }
          });
        }
      });
      executionResult = results && results.find(r => r.result && r.result.ok);
    } catch (e) {
      console.warn('[background] Script execution error in tab main world:', e);
    }

    const recaptchaToken = executionResult ? executionResult.result.token : 'DEFAULT_RECAPTCHA_TOKEN';
    const tabSessionToken = executionResult ? executionResult.result.sessionToken : null;
    const tabProjectId = executionResult ? executionResult.result.projectId : null;
    
    // Check captured webRequest token as backup
    const storedCapturedToken = await getStoredBearerToken();

    function isOAuthToken(t) {
      return t && typeof t === 'string' && t.startsWith('ya29.') && t.length > 30;
    }

    let finalSessionToken = null;
    if (isOAuthToken(request.sessionToken)) finalSessionToken = request.sessionToken;
    else if (isOAuthToken(storedCapturedToken)) finalSessionToken = storedCapturedToken;
    else if (isOAuthToken(tabSessionToken)) finalSessionToken = tabSessionToken;
    else {
      const directTok = await getDirectSessionToken();
      if (isOAuthToken(directTok)) finalSessionToken = directTok;
    }

    if (!finalSessionToken && chrome.cookies) {
      try {
        const cks = await chrome.cookies.getAll({ domain: 'google.com' });
        for (const c of (cks || [])) {
          if (c.value && c.value.includes('ya29.')) {
            const m = c.value.match(/ya29\.[A-Za-z0-9_-]{30,}/);
            if (m && isOAuthToken(m[0])) { finalSessionToken = m[0]; break; }
          }
        }
      } catch (_) {}
    }

    const finalProjectId = request.projectId || reqProjectId || tabProjectId;

    const forwardPayload = Object.assign({}, request, { 
      recaptchaToken: recaptchaToken,
      sessionToken: finalSessionToken,
      projectId: finalProjectId
    });

    // Send to content script with retry
    chrome.tabs.sendMessage(targetTab.id, forwardPayload, (response) => {
      if (chrome.runtime.lastError) {
        const errMsg = chrome.runtime.lastError.message || '';
        if (errMsg.includes('Receiving end does not exist') || errMsg.includes('Could not establish connection')) {
          console.log('[background] Injecting scripts on-the-fly...');
          // Inject interceptor in MAIN world first
          chrome.scripting.executeScript({
            target: { tabId: targetTab.id },
            world: 'MAIN',
            files: ['interceptor.js']
          }).catch(() => {});

          chrome.scripting.executeScript({
            target: { tabId: targetTab.id },
            files: ['content.js']
          }).then(() => {
            chrome.tabs.sendMessage(targetTab.id, forwardPayload, async (retryResponse) => {
              if (chrome.runtime.lastError) {
                performDirectBackgroundGenerate(forwardPayload, sendResponse);
              } else {
                if (retryResponse && Array.isArray(retryResponse.media)) {
                  await ensureMediaHasBase64(retryResponse.media, targetTab.id, finalSessionToken);
                }
                sendResponse(retryResponse || { ok: false, error: 'Empty response from Google Flow content script.' });
              }
            });
          }).catch(() => {
            performDirectBackgroundGenerate(forwardPayload, sendResponse);
          });
          return;
        }

        // Direct background fetch fallback
        performDirectBackgroundGenerate(forwardPayload, sendResponse);
      } else {
        (async () => {
          if (response && Array.isArray(response.media)) {
            await ensureMediaHasBase64(response.media, targetTab.id, finalSessionToken);
          }
          sendResponse(response || { ok: false, error: 'Empty response from Google Flow content script. Please refresh the Google Flow tab.' });
        })();
      }
    });
  } catch (err) {
    console.error('[background] handleGenerateFlow failed:', err);
    sendResponse({ ok: false, error: 'Background generator error: ' + (err.message || String(err)) });
  }
}

// Ensure every media item returned to the web app has base64 encodedImage
async function ensureMediaHasBase64(mediaList, tabId = null, sessionToken = null) {
  if (!Array.isArray(mediaList)) return;
  for (const item of mediaList) {
    if (item.encodedImage && item.encodedImage.length > 500) {
      item.encodedImage = normalizeDataUrl(item.encodedImage);
      continue;
    }

    // 1. Try background HTTP fetch (works directly for Google CDN / Fife URLs)
    let fetchUrl = item.url || '';
    if (fetchUrl.startsWith('/')) {
      fetchUrl = 'https://flow.google.com' + fetchUrl;
    }
    if (fetchUrl.startsWith('http')) {
      try {
        const controller = new AbortController();
        const fetchTimer = setTimeout(() => controller.abort(), 12000);
        
        // Simple fetch first (no Authorization or credentials: 'include' that breaks Google CDN wildcard CORS)
        let resp = null;
        try {
          resp = await fetch(fetchUrl, { signal: controller.signal });
        } catch (_) {}

        // If simple fetch failed and it's on flow.google.com, retry with session authorization
        if ((!resp || !resp.ok) && sessionToken && fetchUrl.includes('flow.google.com')) {
          try {
            resp = await fetch(fetchUrl, { headers: { 'Authorization': 'Bearer ' + sessionToken }, signal: controller.signal });
          } catch (_) {}
        }
        clearTimeout(fetchTimer);

        if (resp && resp.ok) {
          const ct = resp.headers.get('content-type') || 'image/webp';
          const mime = ct.split(';')[0].trim();
          const blob = await resp.blob();
          const buffer = await blob.arrayBuffer();
          const bytes = new Uint8Array(buffer);
          if (bytes.length > 300) {
            let binary = '';
            const chunk = 8192;
            for (let i = 0; i < bytes.length; i += chunk) {
              binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
            }
            item.encodedImage = normalizeDataUrl(btoa(binary), mime);
            console.log('[background] ensureMediaHasBase64 successfully fetched image from HTTP (bytes: ' + bytes.length + ')');
            continue;
          }
        }
      } catch (err) {
        console.warn('[background] ensureMediaHasBase64 fetch error:', err);
      }
    }

    // 2. Fetch blob in tab MAIN world (if item.url is blob:...)
    if ((!item.encodedImage || item.encodedImage.length < 50) && item.url && item.url.startsWith('blob:') && tabId) {
      try {
        const scriptRes = await chrome.scripting.executeScript({
          target: { tabId: tabId },
          world: 'MAIN',
          func: async (blobUrl) => {
            if (!blobUrl) return '';
            try {
              const r = await fetch(blobUrl);
              if (r.ok) {
                const b = await r.blob();
                return await new Promise((res) => {
                  const fr = new FileReader();
                  fr.onloadend = () => res(String(fr.result || ''));
                  fr.onerror = () => res('');
                  fr.readAsDataURL(b);
                });
              }
            } catch (_) {}
            return '';
          },
          args: [item.url]
        });
        const b64 = scriptRes && scriptRes[0] && scriptRes[0].result;
        if (b64 && b64.length > 300) {
          item.encodedImage = normalizeDataUrl(b64);
          console.log('[background] Converted blob to Base64 via tab script execution');
          continue;
        }
      } catch (err) {
        console.warn('[background] Tab script extraction error:', err);
      }
    }

    // 3. Rendered IMG to Canvas fallback inside tab MAIN world
    if ((!item.encodedImage || item.encodedImage.length < 50) && tabId) {
      try {
        const scriptRes = await chrome.scripting.executeScript({
          target: { tabId: tabId },
          world: 'MAIN',
          func: async () => {
            try {
              const imgs = Array.from(document.querySelectorAll('img[src*="googleusercontent.com"], img[src^="blob:"], [data-tile-id] img, article img, img[alt*="Generated" i]'));
              const target = imgs[imgs.length - 1];
              if (target && target.complete && (target.naturalWidth || target.width) > 50) {
                const c = document.createElement('canvas');
                c.width = target.naturalWidth || target.width;
                c.height = target.naturalHeight || target.height;
                const ctx = c.getContext('2d');
                ctx.drawImage(target, 0, 0);
                return c.toDataURL('image/png');
              }
            } catch (_) {}
            return '';
          }
        });
        const b64 = scriptRes && scriptRes[0] && scriptRes[0].result;
        if (b64 && b64.length > 500) {
          item.encodedImage = normalizeDataUrl(b64);
          console.log('[background] Converted rendered img to Base64 via DOM canvas in tab');
          continue;
        }
      } catch (_) {}
    }
  }
}

// Crop screenshot via OffscreenCanvas in Service Worker
async function cropScreenshot(dataUrl, rect) {
  try {
    const resp = await fetch(dataUrl);
    const blob = await resp.blob();
    const bitmap = await createImageBitmap(blob);

    const dpr = rect.dpr || 1;
    const sx = Math.max(0, Math.round(rect.x * dpr));
    const sy = Math.max(0, Math.round(rect.y * dpr));
    const sw = Math.min(bitmap.width - sx, Math.round(rect.width * dpr));
    const sh = Math.min(bitmap.height - sy, Math.round(rect.height * dpr));

    if (sw <= 10 || sh <= 10) return null;

    const canvas = new OffscreenCanvas(sw, sh);
    const ctx = canvas.getContext('2d');
    ctx.drawImage(bitmap, sx, sy, sw, sh, 0, 0, sw, sh);

    try {
      const sampleW = Math.min(sw, 40);
      const sampleH = Math.min(sh, 40);
      const imgData = ctx.getImageData(0, 0, sampleW, sampleH);
      let hasColor = false;
      for (let i = 0; i < imgData.data.length; i += 4) {
        if (imgData.data[i] > 30 || imgData.data[i + 1] > 30 || imgData.data[i + 2] > 30) {
          hasColor = true;
          break;
        }
      }
      if (!hasColor) {
        console.warn('[background] Cropped screenshot is solid black. Discarding.');
        return null;
      }
    } catch (_) {}

    const outBlob = await canvas.convertToBlob({ type: 'image/png' });
    const buffer = await outBlob.arrayBuffer();
    const bytes = new Uint8Array(buffer);
    let binary = '';
    const chunk = 8192;
    for (let i = 0; i < bytes.length; i += chunk) {
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
    }
    return `data:image/png;base64,${btoa(binary)}`;
  } catch (e) {
    console.warn('[background] cropScreenshot failed:', e);
    return null;
  }
}

// Backup direct background fetch if content script is unresponsive
async function performDirectBackgroundGenerate(payload, sendResponse) {
  try {
    const projectId = payload.projectId;
    const token = payload.sessionToken;

    if (!projectId) {
      sendResponse({ ok: false, error: 'Could not determine Flow projectId. Please open a project in your Google Flow tab.' });
      return;
    }
    if (!token) {
      sendResponse({ ok: false, error: 'No active Google session found. Please refresh your Google Flow tab (flow.google.com) once while signed in to Google, then click Start Flow Engine again.' });
      return;
    }

    const model = payload.options?.model || 'NARWHAL';
    const arMode = payload.options?.aspectRatio || '16:9';
    const aspectRatios = {
      '1:1': 'IMAGE_ASPECT_RATIO_SQUARE',
      '16:9': 'IMAGE_ASPECT_RATIO_LANDSCAPE',
      '9:16': 'IMAGE_ASPECT_RATIO_PORTRAIT',
      '4:3': 'IMAGE_ASPECT_RATIO_LANDSCAPE_FOUR_THREE',
      '3:4': 'IMAGE_ASPECT_RATIO_PORTRAIT_THREE_FOUR'
    };
    const arKey = aspectRatios[arMode] || aspectRatios['16:9'];

    let seedVal = payload.options?.seed;
    if (seedVal === null || seedVal === undefined) {
      seedVal = Math.floor(Math.random() * 2147483648);
    }
    seedVal = Math.abs(Math.trunc(Number(seedVal) || 0)) % 2147483648;

    const clientContext = {
      recaptchaContext: { token: payload.recaptchaToken || 'DEFAULT_RECAPTCHA_TOKEN', applicationType: 'RECAPTCHA_APPLICATION_TYPE_WEB' },
      projectId: projectId,
      tool: 'PINHOLE'
    };

    const bodyObj = {
      clientContext: Object.assign({}, clientContext, { sessionId: ';' + Date.now() }),
      mediaGenerationContext: { batchId: crypto.randomUUID() },
      useNewMedia: true,
      requests: [{
        clientContext: clientContext,
        imageModelName: model,
        imageAspectRatio: arKey,
        structuredPrompt: { parts: [{ text: String(payload.prompt || '') }] },
        seed: seedVal
      }]
    };

    const endpoint = `https://aisandbox-pa.googleapis.com/v1/projects/${projectId}/flowMedia:batchGenerateImages`;
    const resp = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(bodyObj)
    });

    const text = await resp.text();
    if (!resp.ok) {
      sendResponse({ ok: false, error: `Google Flow HTTP error ${resp.status}: ${text.substring(0, 300)}` });
      return;
    }

    const data = JSON.parse(text);
    if (!data || !data.media || data.media.length === 0) {
      const apiErrorMsg = (data && data.error && data.error.message) || 'Google Flow returned an empty media list. Please ensure your account has active prompt quota and flow.google.com is open.';
      sendResponse({ ok: false, error: apiErrorMsg });
      return;
    }

    const mediaResult = [];
    let detailedIssue = null;

    for (const item of data.media) {
      if (item.error && item.error.message) {
        detailedIssue = item.error.message;
        continue;
      }
      if (item.safetyFeedback || (item.workflow && item.workflow.status === 'SAFETY_BLOCKED')) {
        detailedIssue = 'Prompt blocked by Google Flow safety or moderation filters.';
        continue;
      }

      const g = (item.image && item.image.generatedImage) || item.generatedImage || item.image || item;
      let resolvedFife = fifeUrl;
      if (resolvedFife && resolvedFife.startsWith('/')) {
        resolvedFife = 'https://flow.google.com' + resolvedFife;
      }

      if (resolvedFife && !b64) {
        try {
          const fetchHeaders = token ? { 'Authorization': 'Bearer ' + token } : {};
          const imgResp = await fetch(resolvedFife, { headers: fetchHeaders });
          if (imgResp.ok) {
            const ct = imgResp.headers.get('content-type') || 'image/webp';
            const mime = ct.split(';')[0].trim();
            const blob = await imgResp.blob();
            const buffer = await blob.arrayBuffer();
            const bytes = new Uint8Array(buffer);
            let binary = '';
            const chunk = 8192;
            for (let i = 0; i < bytes.length; i += chunk) {
              binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
            }
            b64 = normalizeDataUrl(btoa(binary), mime);
          }
        } catch (e) {
          console.warn('[background] Direct base64 fetch fallback:', e);
        }
      }

      if (b64) {
        b64 = normalizeDataUrl(b64);
      }

      if (b64 || fifeUrl) {
        mediaResult.push({
          id: item.id || crypto.randomUUID(),
          url: resolvedFife || fifeUrl,
          encodedImage: b64 || ''
        });
      }
    }

    if (mediaResult.length === 0) {
      sendResponse({ 
        ok: false, 
        error: detailedIssue || 'Google Flow did not return any valid image data. Please check your Google Flow tab, remaining quota, or adjust your prompt.' 
      });
      return;
    }

    sendResponse({ ok: true, media: mediaResult });
  } catch (e) {
    sendResponse({ ok: false, error: 'Direct background generation exception: ' + (e.message || String(e)) });
  }
}
