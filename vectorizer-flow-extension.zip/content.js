// Content Script for Google Flow (flow.google.com / labs.google)

function detectMimeFromBase64(b64) {
  if (!b64 || typeof b64 !== 'string') return null;
  const clean = b64.replace(/^data:[^,]+,/, '').trim();
  if (clean.startsWith('iVBORw0KGgo')) return 'image/png';
  if (clean.startsWith('/9j/')) return 'image/jpeg';
  if (clean.startsWith('UklGR')) return 'image/webp';
  if (clean.startsWith('R0lGOD')) return 'image/gif';
  if (clean.startsWith('PHN2Zy') || clean.startsWith('PD94bWw')) return 'image/svg+xml';
  return null;
}

function normalizeDataUrl(input, fallbackMime = 'image/png') {
  if (!input || typeof input !== 'string') return '';
  const str = input.trim();
  if (str.startsWith('data:')) {
    const commaIdx = str.indexOf(',');
    if (commaIdx !== -1) {
      const b64Data = str.substring(commaIdx + 1);
      const detected = detectMimeFromBase64(b64Data);
      if (detected) {
        return `data:${detected};base64,${b64Data}`;
      }
      return str;
    }
    return str;
  }
  const detected = detectMimeFromBase64(str) || fallbackMime;
  return `data:${detected};base64,${str}`;
}

// Listen for messages from background.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('[content] Received message from background:', request);

  if (request.action === 'generate') {
    handleGenerate(request)
      .then(result => {
        sendResponse(result);
      })
      .catch(error => {
        console.error('[content] Generation failed:', error);
        sendResponse({ ok: false, error: error.message || String(error) });
      });
    return true; // Keep channel open for async response
  }

  sendResponse({ ok: false, error: 'Unknown action: ' + request.action });
  return false;
});

// Main generation driver running inside Google Flow context
async function handleGenerate(request) {
  const promptText = String(request.prompt || '').trim();
  if (!promptText) {
    throw new Error('Prompt cannot be empty.');
  }

  // 1. Get Project ID (check request payload first, then discover from page)
  const projectId = request.projectId || discoverProjectId();
  
  // 2. Check for active Google OAuth Bearer Token (must start with ya29.)
  const token = request.sessionToken || await fetchSessionToken();
  const isValidOAuth = token && typeof token === 'string' && token.startsWith('ya29.') && token.length > 30;

  // 3. If valid OAuth token and project ID exist, try direct API generation first (Fast Path)
  if (isValidOAuth && projectId) {
    try {
      console.log('[content] Trying direct API fetch with valid OAuth token...');
      const apiResult = await generateViaDirectApi(request, projectId, token);
      if (apiResult && apiResult.ok && apiResult.media && apiResult.media.length > 0) {
        console.log('[content] Direct API generation succeeded!');
        return apiResult;
      }
    } catch (apiErr) {
      console.warn('[content] Direct API generation failed:', apiErr.message, 'Falling back to in-tab DOM automation...');
    }
  } else {
    console.log('[content] No fresh ya29 OAuth token available. Using in-tab DOM automation generator...');
  }

  // 4. Fallback Path: In-Tab Native DOM Generation (Self-Healing & Guaranteed)
  return await generateViaDom(request);
}

// Fast Path: Direct fetch to aisandbox-pa API
async function generateViaDirectApi(request, projectId, token) {
  const recaptchaToken = request.recaptchaToken || await generateRecaptcha(request) || 'DEFAULT_RECAPTCHA_TOKEN';
  const model = request.options?.model || 'NARWHAL';
  const arMode = request.options?.aspectRatio || '16:9';
  const aspectRatios = {
    '1:1': 'IMAGE_ASPECT_RATIO_SQUARE',
    '16:9': 'IMAGE_ASPECT_RATIO_LANDSCAPE',
    '9:16': 'IMAGE_ASPECT_RATIO_PORTRAIT',
    '4:3': 'IMAGE_ASPECT_RATIO_LANDSCAPE_FOUR_THREE',
    '3:4': 'IMAGE_ASPECT_RATIO_PORTRAIT_THREE_FOUR'
  };
  const arKey = aspectRatios[arMode] || aspectRatios['16:9'];

  let seedVal = request.options?.seed;
  if (seedVal === null || seedVal === undefined) {
    seedVal = Math.floor(Math.random() * 2147483648);
  }
  seedVal = Math.abs(Math.trunc(Number(seedVal) || 0)) % 2147483648;

  const clientContext = {
    recaptchaContext: { token: recaptchaToken, applicationType: 'RECAPTCHA_APPLICATION_TYPE_WEB' },
    projectId: projectId,
    tool: 'PINHOLE'
  };

  const payload = {
    clientContext: Object.assign({}, clientContext, { sessionId: ';' + Date.now() }),
    mediaGenerationContext: { batchId: crypto.randomUUID() },
    useNewMedia: true,
    requests: [{
      clientContext: clientContext,
      imageModelName: model,
      imageAspectRatio: arKey,
      structuredPrompt: { parts: [{ text: String(request.prompt || '') }] },
      seed: seedVal
    }]
  };

  const endpoint = `https://aisandbox-pa.googleapis.com/v1/projects/${projectId}/flowMedia:batchGenerateImages`;
  console.log('[content] Sending direct API request payload to:', endpoint);

  const response = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Authorization': 'Bearer ' + token,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  });

  const resultText = await response.text();
  if (!response.ok) {
    throw new Error(`Google Flow HTTP error ${response.status}: ${resultText.substring(0, 300)}`);
  }

  let data = null;
  try {
    data = JSON.parse(resultText);
  } catch (e) {
    throw new Error('Google Flow response was not valid JSON: ' + resultText.substring(0, 200));
  }

  if (!data || !data.media || data.media.length === 0) {
    throw new Error('Google Flow returned an empty media list.');
  }

  return await parseMediaItems(data.media);
}

// Persistent set of media keys already returned in this tab session so we never re-extract old items
// Persistent set of media keys already returned in this tab session so we never re-extract old items
const globallyClaimedMediaKeys = new Set();

const COMPLETION_SELECTORS = [
  'img[src*="media.getMediaUrlRedirect"]',
  'video[src*="media.getMediaUrlRedirect"]',
  'img[src*="googleusercontent.com"]',
  'video[src*="googleusercontent.com"]',
  'img[src^="blob:"]',
  'video[src^="blob:"]',
  'img[alt*="Generated" i]',
  'video[alt*="Generated" i]',
  '[data-tile-id] img',
  '[data-tile-id] video',
  '[data-item-index] img',
  '[data-item-index] video',
  '[data-test-id="media-tile"] img',
  '[data-test-id="media-tile"] video',
  'article img',
  'article video',
  '[role="listitem"] img',
  '[role="listitem"] video',
  '.sc-result-media img',
  '.sc-result-media video',
  '[data-testid*="media" i] img',
  '[data-testid*="media" i] video',
  'canvas',
  'main img',
  'main video',
  'img[src]',
  'video[src]',
  'img',
  'video'
];

function hasGenerationSpinner() {
  const activeSpinners = document.querySelectorAll(
    '[aria-busy="true"], [data-state="generating"], .animate-spin, svg.animate-spin, ' +
    '.sc-generating-spinner, [role="progressbar"], ' +
    '[data-testid*="spinner" i], [data-testid*="loading" i], [aria-label*="Loading" i], [aria-label*="Generating" i]'
  );
  for (const sp of activeSpinners) {
    if (sp.offsetParent !== null || (sp.getClientRects && sp.getClientRects().length > 0)) {
      try {
        const style = window.getComputedStyle(sp);
        if (style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0') {
          return true;
        }
      } catch (_) {
        return true;
      }
    }
  }
  return false;
}

function getMediaSourceUrl(el) {
  if (!el) return null;
  if (el.tagName === 'IMG') return el.currentSrc || el.src || el.getAttribute?.('src') || null;
  if (el.tagName === 'VIDEO') {
    return el.currentSrc || el.src || el.querySelector?.('source')?.src || el.getAttribute?.('src') || null;
  }
  if (el.tagName === 'SOURCE') {
    return el.currentSrc || el.src || el.getAttribute?.('src') || null;
  }
  const bg = el.style?.backgroundImage || '';
  if (bg && bg.includes('url(')) {
    const m = bg.match(/url\(['"]?(.*?)['"]?\)/);
    if (m && m[1]) return m[1];
  }
  return el.getAttribute?.('src') || el.getAttribute?.('href') || null;
}

function getMediaKey(el) {
  if (!el) return null;
  const tag = (el.tagName || '').toUpperCase();
  if (tag === 'IMG') {
    const src = el.currentSrc || el.src || el.getAttribute?.('src') || '';
    return src ? `img:${src}` : null;
  }
  if (tag === 'VIDEO') {
    const src = el.currentSrc || el.src || el.querySelector?.('source')?.src || el.getAttribute?.('src') || '';
    return src ? `video:${src}` : null;
  }
  if (tag === 'CANVAS') {
    return `canvas:${el.width}x${el.height}`;
  }
  const src = el.getAttribute?.('src') || el.getAttribute?.('href') || '';
  return src ? `${tag.toLowerCase()}:${src}` : null;
}

function findPromptForImage(img) {
  if (!img) return '';
  // 1. Walk up to 12 parent levels looking for prompt text badge
  let node = img;
  for (let depth = 0; depth < 12 && node; depth++) {
    const promptEl = node.querySelector?.('[data-allow-text-selection="true"], .hxRvgy, .sc-prompt-text, [class*="prompt" i]');
    if (promptEl) {
      const t = (promptEl.innerText || promptEl.textContent || '').trim();
      if (t && t.length > 3) return t;
    }
    node = node.parentElement;
  }
  // 2. Find closest tile container
  const container = img.closest?.('[data-item-index], [data-tile-id], [data-test-id="media-tile"], article, li, [role="listitem"]');
  if (container) {
    const promptEl = container.querySelector?.('[data-allow-text-selection="true"], .hxRvgy, .sc-prompt-text, [class*="prompt" i]');
    if (promptEl) {
      const t = (promptEl.innerText || promptEl.textContent || '').trim();
      if (t && t.length > 3) return t;
    }
  }
  // 3. Find nearest prompt on page
  try {
    const allPrompts = Array.from(document.querySelectorAll('[data-allow-text-selection="true"], .hxRvgy, .sc-prompt-text'));
    if (allPrompts.length > 0) {
      const imgRect = img.getBoundingClientRect?.();
      if (imgRect) {
        const nearest = allPrompts.reduce((best, p) => {
          const r = p.getBoundingClientRect();
          const dist = Math.abs(r.top - imgRect.top) + Math.abs(r.left - imgRect.left);
          return (!best || dist < best.dist) ? { el: p, dist } : best;
        }, null);
        if (nearest && nearest.el) {
          const t = (nearest.el.innerText || nearest.el.textContent || '').trim();
          if (t && t.length > 3) return t;
        }
      }
    }
  } catch (_) {}
  return '';
}

function normalizePromptText(p) {
  return String(p || '').toLowerCase().replace(/[^a-z0-9]/g, '').trim();
}

function promptMatchesTarget(cardPrompt, targetPrompt) {
  const c = normalizePromptText(cardPrompt);
  const t = normalizePromptText(targetPrompt);
  if (!c || !t) return false;
  if (c === t || c.includes(t) || t.includes(c)) return true;
  const len = Math.min(c.length, t.length, 30);
  if (len >= 10 && (c.slice(0, len) === t.slice(0, len))) return true;
  return false;
}

function isValidGeneratedMediaElement(el) {
  if (!el || !el.isConnected) return false;

  const tag = (el.tagName || '').toUpperCase();
  if (tag !== 'IMG' && tag !== 'VIDEO' && tag !== 'CANVAS' && tag !== 'SOURCE') return false;

  const url = (getMediaSourceUrl(el) || el.getAttribute?.('src') || el.getAttribute?.('href') || '').toLowerCase();
  if (tag !== 'CANVAS' && (!url || url.startsWith('data:image/svg') || url.includes('favicon') || url.includes('/assets/') || url.includes('/static/'))) {
    return false;
  }

  // Exclude Profile Avatar / Google Account Logo
  const alt = (el.getAttribute?.('alt') || '').toLowerCase();
  const title = (el.getAttribute?.('title') || '').toLowerCase();
  const ariaLabel = (el.getAttribute?.('aria-label') || '').toLowerCase();
  const className = (typeof el.className === 'string' ? el.className : '').toLowerCase();
  const id = (el.id || '').toLowerCase();

  if (
    alt.includes('google account') || alt.includes('profile') || alt.includes('avatar') || alt.includes('user icon') ||
    title.includes('google account') || title.includes('profile') || title.includes('avatar') ||
    ariaLabel.includes('google account') || ariaLabel.includes('profile') || ariaLabel.includes('avatar') ||
    className.includes('avatar') || className.includes('profile') || className.includes('user-icon') || className.includes('usericon') ||
    id.includes('avatar') || id.includes('profile')
  ) {
    return false;
  }

  // Exclude images inside header, nav, or user account menu buttons
  const inHeaderOrNav = !!el.closest?.('header, nav, [role="banner"], [data-testid*="header" i], [data-testid*="avatar" i], button[aria-label*="Google Account" i], button[aria-label*="Account" i], .sc-header');
  if (inHeaderOrNav) return false;

  // Google Profile / Account photo URL signatures
  if (url.includes('googleusercontent.com/a/') || url.includes('googleusercontent.com/ogp/') || /\/a\/[A-Za-z0-9_-]+=/i.test(url) || /=s\d{2,3}-c/i.test(url)) {
    return false;
  }

  // Dimension filter
  if (tag === 'IMG') {
    const nw = el.naturalWidth || 0;
    const nh = el.naturalHeight || 0;
    if (nw > 0 && nh > 0 && nw < 50 && nh < 50) {
      return false;
    }
  }

  const rect = el.getBoundingClientRect?.();
  if (rect && rect.width > 0 && rect.height > 0) {
    if (rect.width < 50 && rect.height < 50) {
      const isTile = !!el.closest?.('[data-tile-id], [data-item-index], [data-testid*="media" i], article');
      if (!isTile) return false;
    }
  }

  return true;
}

function getAllCandidateMediaElements() {
  const seenElements = new Set();
  const validList = [];

  for (const sel of COMPLETION_SELECTORS) {
    const list = Array.from(document.querySelectorAll(sel));
    for (const el of list) {
      if (seenElements.has(el)) continue;
      seenElements.add(el);
      if (isValidGeneratedMediaElement(el)) {
        validList.push(el);
      }
    }
  }

  return validList;
}

// Guaranteed Path: In-Tab Native DOM Generation
async function generateViaDom(request) {
  const promptText = String(request.prompt || '').trim();
  console.log('[content] Starting in-tab DOM generation for prompt:', promptText.substring(0, 40) + '...');

  // 1. Snapshot existing media keys on page before submitting
  const baselineKeys = new Set();
  try {
    getAllCandidateMediaElements().forEach(el => {
      const k = getMediaKey(el);
      if (k) baselineKeys.add(k);
    });
  } catch (_) {}
  console.log('[content] Pre-generation baseline has ' + baselineKeys.size + ' media items');

  // 2. Set up listeners for network interception events
  let interceptedMedia = null;
  let interceptedError = null;

  const onWindowMessage = (event) => {
    if (!event.data || typeof event.data !== 'object') return;
    if (event.data.type === '__GRAVITY_FLOW_MEDIA_GENERATED__' && Array.isArray(event.data.media) && event.data.media.length > 0) {
      console.log('[content] Received __GRAVITY_FLOW_MEDIA_GENERATED__ via postMessage:', event.data.media.length, 'items');
      interceptedMedia = event.data.media;
    } else if (event.data.type === '__GRAVITY_FLOW_MEDIA_ERROR__') {
      interceptedError = event.data;
    }
  };

  const onCustomEventGenerated = (e) => {
    if (e.detail && Array.isArray(e.detail) && e.detail.length > 0) {
      console.log('[content] Received __GRAVITY_FLOW_MEDIA_GENERATED__ via CustomEvent:', e.detail.length, 'items');
      interceptedMedia = e.detail;
    }
  };

  const onCustomEventError = (e) => {
    if (e.detail) interceptedError = e.detail;
  };

  window.addEventListener('message', onWindowMessage);
  window.addEventListener('__GRAVITY_FLOW_MEDIA_GENERATED__', onCustomEventGenerated);
  window.addEventListener('__GRAVITY_FLOW_MEDIA_ERROR__', onCustomEventError);

  try {
    // 3. Locate prompt input element
    let inputEl = await waitForPromptInput(6000);
    if (!inputEl) {
      throw new Error('Could not find Google Flow prompt box. Please make sure a project is open on flow.google.com.');
    }

    // 4. Fill the prompt into the composer
    const filled = await setPromptText(inputEl, promptText);
    if (!filled) {
      throw new Error('Could not insert prompt text into Google Flow composer.');
    }

    await new Promise(r => setTimeout(r, 150));

    // 5. Locate and click Generate / Create submit button
    const submitted = await clickGenerateSubmit(inputEl);
    if (!submitted) {
      throw new Error('Could not trigger Generate button on Google Flow. Please check if the prompt box is active.');
    }

    console.log('[content] Submit button clicked. Waiting for generation response...');

    // 6. Wait for result (prompt match, network intercepted event, or DOM element)
    const startTime = Date.now();
    const timeoutMs = 75000; // 75 seconds max
    let sawGenerating = false;
    let lastHeartbeat = 0;

    while (Date.now() - startTime < timeoutMs) {
      const elapsed = Date.now() - startTime;

      // Keep MV3 Background Service Worker alive by sending heartbeat every 2 seconds
      if (Date.now() - lastHeartbeat > 2000) {
        lastHeartbeat = Date.now();
        try {
          chrome.runtime.sendMessage({ action: 'GENERATION_HEARTBEAT' }).catch(() => {});
        } catch (_) {}
      }

      // Priority A: Check network intercepted event
      let candidateMedia = null;
      if (interceptedMedia && interceptedMedia.length > 0) {
        candidateMedia = interceptedMedia;
      } else {
        try {
          if (typeof window !== 'undefined' && window.__LAST_FLOW_MEDIA__ && window.__LAST_FLOW_MEDIA__.at >= startTime && Array.isArray(window.__LAST_FLOW_MEDIA__.media)) {
            candidateMedia = window.__LAST_FLOW_MEDIA__.media;
          }
        } catch (_) {}
      }

      if (candidateMedia && candidateMedia.length > 0) {
        try {
          const parsed = await parseMediaItems(candidateMedia);
          if (parsed && parsed.ok && parsed.media && parsed.media.length > 0) {
            console.log('[content] Generated media retrieved via network payload:', parsed.media.length);
            return parsed;
          }
        } catch (err) {
          console.warn('[content] Network payload parsing failed, falling back to DOM detection:', err);
          interceptedMedia = null;
          if (typeof window !== 'undefined') window.__LAST_FLOW_MEDIA__ = null;
        }
      }

      if (interceptedError) {
        throw new Error(`Google Flow generation error: ${interceptedError.error || 'Server error ' + interceptedError.status}`);
      }

      // Priority B: Track spinner / progress
      const hasSpinner = hasGenerationSpinner();
      if (hasSpinner) {
        sawGenerating = true;
      }

      const allCandidates = getAllCandidateMediaElements();

      // Priority C: Direct Prompt Text Match on Google Flow Cards
      const matchingCandidate = allCandidates.find(el => {
        const k = getMediaKey(el);
        if (k && globallyClaimedMediaKeys.has(k)) return false;
        const cardPrompt = findPromptForImage(el);
        return cardPrompt && promptMatchesTarget(cardPrompt, promptText);
      });

      if (matchingCandidate) {
        const nw = matchingCandidate.naturalWidth || 0;
        const isReady = (matchingCandidate.tagName === 'CANVAS') ||
                        (matchingCandidate.tagName === 'VIDEO' && matchingCandidate.readyState >= 2) ||
                        (matchingCandidate.tagName === 'IMG' && (matchingCandidate.complete || nw > 50 || elapsed >= 2500));
        if (isReady) {
          console.log('[content] Found media matching prompt directly on board!');
          const extracted = await extractMediaFromElement(matchingCandidate);
          if (extracted && (extracted.encodedImage || extracted.url || extracted.elementRect)) {
            const k = getMediaKey(matchingCandidate);
            if (k) globallyClaimedMediaKeys.add(k);
            return { ok: true, media: [extracted] };
          }
        }
      }

      // Priority D: DOM detection of newly generated media elements (not in baseline)
      const newMediaElements = allCandidates.filter(el => {
        const k = getMediaKey(el);
        return k && !baselineKeys.has(k) && !globallyClaimedMediaKeys.has(k);
      });

      if (newMediaElements.length > 0 && (elapsed >= 2500 || sawGenerating)) {
        const firstEl = newMediaElements[0];
        const isReady = (firstEl.tagName === 'CANVAS') ||
                        (firstEl.tagName === 'VIDEO' && firstEl.readyState >= 2) ||
                        (firstEl.tagName === 'IMG' && (firstEl.complete || (firstEl.naturalWidth && firstEl.naturalWidth > 50) || elapsed > 5000));

        if (isReady && (!hasSpinner || elapsed > 5000)) {
          console.log('[content] Detected ' + newMediaElements.length + ' newly generated media elements on board.');
          const extractedMedia = [];
          for (const el of newMediaElements.slice(0, 4)) {
            const extracted = await extractMediaFromElement(el);
            if (extracted && (extracted.encodedImage || extracted.url || extracted.elementRect)) {
              const k = getMediaKey(el);
              if (k) globallyClaimedMediaKeys.add(k);
              extractedMedia.push(extracted);
            }
          }
          if (extractedMedia.length > 0) {
            return { ok: true, media: extractedMedia };
          }
        }
      }

      // Priority E Fallback: If spinner disappeared or after 8s elapsed
      if ((sawGenerating && !hasSpinner && elapsed > 3000) || (!hasSpinner && elapsed > 8000) || (elapsed > 16000)) {
        const unclaimed = allCandidates.filter(el => {
          const k = getMediaKey(el);
          return k && !globallyClaimedMediaKeys.has(k);
        });
        if (unclaimed.length > 0) {
          console.log('[content] Generation finished fallback. Extracting latest media on board...');
          const target = unclaimed[unclaimed.length - 1]; // pick the most recent on the board
          const extracted = await extractMediaFromElement(target);
          if (extracted && (extracted.encodedImage || extracted.url || extracted.elementRect)) {
            const k = getMediaKey(target);
            if (k) globallyClaimedMediaKeys.add(k);
            return { ok: true, media: [extracted] };
          }
        }
      }

      await new Promise(r => setTimeout(r, 200));
    }

    throw new Error('Generation timed out waiting for Google Flow. Please ensure your Google Flow tab is signed in and responsive.');
  } finally {
    window.removeEventListener('message', onWindowMessage);
    window.removeEventListener('__GRAVITY_FLOW_MEDIA_GENERATED__', onCustomEventGenerated);
    window.removeEventListener('__GRAVITY_FLOW_MEDIA_ERROR__', onCustomEventError);
  }
}

// Multi-layer base64 extractor (direct canvas + MAIN world + tab fetch + elementRect)
async function extractMediaFromElement(el) {
  const url = getMediaSourceUrl(el) || '';
  let b64 = '';

  // 1. Direct canvas extraction from already-rendered IMG (fastest and zero-network if same origin or cross-origin permitted)
  if (el && el.tagName === 'IMG' && el.complete && (el.naturalWidth || el.width) > 50) {
    try {
      const canvas = document.createElement('canvas');
      canvas.width = el.naturalWidth || el.width;
      canvas.height = el.naturalHeight || el.height;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(el, 0, 0);
      const du = canvas.toDataURL('image/png');
      if (du && du.length > 500) b64 = du;
    } catch (_) {}
  }

  // 2. If Canvas element
  if (!b64 && el && el.tagName === 'CANVAS') {
    try {
      const du = el.toDataURL('image/png');
      if (du && du.length > 200) b64 = du;
    } catch (_) {}
  }

  // 3. Tab fetch with credentials (handles blob: and relative/same-origin images)
  const resolvedUrl = url ? (url.startsWith('/') ? (window.location.origin + url) : url) : '';
  if (!b64 && resolvedUrl) {
    try {
      const resp = await fetch(resolvedUrl);
      if (resp.ok) {
        const blob = await resp.blob();
        if (blob && blob.size > 100) {
          b64 = await new Promise((res) => {
            const fr = new FileReader();
            fr.onloadend = () => res(fr.result || '');
            fr.onerror = () => res('');
            fr.readAsDataURL(blob);
          });
        }
      }
    } catch (_) {}
  }

  // 4. Ask MAIN world via CustomEvent (handles blob URLs and canvases natively in page context)
  if (!b64 && resolvedUrl) {
    try {
      const reqId = crypto.randomUUID();
      const p = new Promise(resolve => {
        let done = false;
        const handler = (e) => {
          if (done) return;
          done = true;
          window.removeEventListener('__GRAVITY_EXTRACT_BASE64_RES__' + reqId, handler);
          resolve(e.detail?.b64 || '');
        };
        window.addEventListener('__GRAVITY_EXTRACT_BASE64_RES__' + reqId, handler);
        setTimeout(() => {
          if (!done) {
            done = true;
            window.removeEventListener('__GRAVITY_EXTRACT_BASE64_RES__' + reqId, handler);
            resolve('');
          }
        }, 1500);
      });

      window.dispatchEvent(new CustomEvent('__GRAVITY_EXTRACT_BASE64__', {
        detail: { reqId, src: resolvedUrl }
      }));

      const resB64 = await p;
      if (resB64) {
        b64 = resB64;
      }
    } catch (_) {}
  }

  // 5. Scroll element into view and calculate viewport rect for fallback tab capture
  let elementRect = null;
  try {
    if (el && el.isConnected) {
      el.scrollIntoView?.({ behavior: 'instant', block: 'center', inline: 'center' });
      const rect = el.getBoundingClientRect?.();
      if (rect && rect.width > 20 && rect.height > 20) {
        elementRect = {
          x: Math.max(0, rect.left),
          y: Math.max(0, rect.top),
          width: rect.width,
          height: rect.height,
          dpr: window.devicePixelRatio || 1
        };
      }
    }
  } catch (_) {}

  const finalB64 = b64 ? normalizeDataUrl(b64) : '';
  return {
    id: crypto.randomUUID(),
    url: resolvedUrl || url,
    encodedImage: finalB64,
    elementRect: elementRect
  };
}

// Convert media items to standard response with base64
async function parseMediaItems(mediaList) {
  const mediaResult = [];
  let detailedIssue = null;

  for (const item of mediaList) {
    if (item.error && item.error.message) {
      detailedIssue = item.error.message;
      continue;
    }
    if (item.safetyFeedback || (item.workflow && item.workflow.status === 'SAFETY_BLOCKED')) {
      detailedIssue = 'Prompt blocked by Google Flow safety or moderation filters.';
      continue;
    }

    const g = (item.image && item.image.generatedImage) || item.generatedImage || item.image || item;
    const fifeUrl = g.fifeUrl || item.fifeUrl || (item.image && item.image.fifeUrl) || g.url || '';
    let b64 = g.encodedImage || item.encodedImage || (item.image && item.image.encodedImage) || item.imageBytes || null;

    if (fifeUrl && !b64) {
      try {
        const resolved = fifeUrl.startsWith('/') ? (window.location.origin + fifeUrl) : fifeUrl;
        const imgResp = await fetch(resolved);
        if (imgResp.ok) {
          const blob = await imgResp.blob();
          b64 = await new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(String(reader.result || ''));
            reader.onerror = reject;
            reader.readAsDataURL(blob);
          });
        }
      } catch (e) {
        console.warn('[content] Base64 fetch fallback:', e);
      }
    }

    if (b64) {
      b64 = normalizeDataUrl(b64);
    }

    if (b64 || fifeUrl) {
      mediaResult.push({
        id: item.id || crypto.randomUUID(),
        url: fifeUrl,
        encodedImage: b64 || ''
      });
    }
  }

  if (mediaResult.length === 0) {
    throw new Error(detailedIssue || 'Google Flow did not return any valid image data. Please check your Google Flow tab.');
  }

  return { ok: true, media: mediaResult };
}

// DOM Helpers
async function waitForPromptInput(timeoutMs = 6000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const el = findPromptInput();
    if (el) return el;
    await new Promise(r => setTimeout(r, 250));
  }
  return null;
}

function findPromptInput() {
  // 1. Slate editor
  const slate = document.querySelector('[data-slate-editor="true"]');
  if (slate) return slate;

  // 2. Standard contenteditable / multiline textbox
  const editables = Array.from(document.querySelectorAll('[role="textbox"][aria-multiline="true"], [data-lexical-editor="true"], div[contenteditable="true"], div[contenteditable="plaintext-only"]'));
  if (editables.length > 0) return editables[0];

  // 3. Textarea
  const textareas = Array.from(document.querySelectorAll('textarea'));
  const validTa = textareas.find(t => !t.placeholder?.toLowerCase().includes('search'));
  if (validTa) return validTa;

  return null;
}

async function setPromptText(inputEl, text) {
  inputEl.focus();

  // Try MAIN world Slate insert function first via CustomEvent
  try {
    const res = await new Promise((resolve) => {
      let settled = false;
      const handler = (e) => {
        if (settled) return;
        settled = true;
        window.removeEventListener('__GRAVITY_EXEC_INSERT_PROMPT_RESULT__', handler);
        resolve(e.detail === true);
      };
      window.addEventListener('__GRAVITY_EXEC_INSERT_PROMPT_RESULT__', handler);
      window.dispatchEvent(new CustomEvent('__GRAVITY_EXEC_INSERT_PROMPT__', { detail: text }));
      setTimeout(() => {
        if (!settled) {
          settled = true;
          window.removeEventListener('__GRAVITY_EXEC_INSERT_PROMPT_RESULT__', handler);
          resolve(false);
        }
      }, 500);
    });
    if (res) return true;
  } catch (_) {}

  // Fallback: React native setter
  try {
    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value").set;
    if (nativeInputValueSetter && inputEl.tagName === 'TEXTAREA') {
      nativeInputValueSetter.call(inputEl, text);
      inputEl.dispatchEvent(new Event('input', { bubbles: true }));
      return true;
    }
  } catch (_) {}

  // Fallback: document.execCommand with selection range
  try {
    const sel = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(inputEl);
    sel.removeAllRanges();
    sel.addRange(range);
    const success = document.execCommand('insertText', false, text);
    if (success) {
      inputEl.dispatchEvent(new Event('input', { bubbles: true }));
      return true;
    }
  } catch (_) {}

  // Fallback: value / innerText
  if (inputEl.tagName === 'TEXTAREA' || inputEl.tagName === 'INPUT') {
    inputEl.value = text;
    inputEl.dispatchEvent(new Event('input', { bubbles: true }));
    inputEl.dispatchEvent(new Event('change', { bubbles: true }));
  } else {
    inputEl.innerText = text;
    inputEl.dispatchEvent(new Event('input', { bubbles: true }));
    inputEl.dispatchEvent(new Event('change', { bubbles: true }));
  }
  return true;
}

async function clickGenerateSubmit(inputEl) {
  // Try MAIN world submit function first via CustomEvent
  try {
    const res = await new Promise((resolve) => {
      let settled = false;
      const handler = (e) => {
        if (settled) return;
        settled = true;
        window.removeEventListener('__GRAVITY_EXEC_CLICK_SUBMIT_RESULT__', handler);
        resolve(e.detail === true);
      };
      window.addEventListener('__GRAVITY_EXEC_CLICK_SUBMIT_RESULT__', handler);
      window.dispatchEvent(new CustomEvent('__GRAVITY_EXEC_CLICK_SUBMIT__'));
      setTimeout(() => {
        if (!settled) {
          settled = true;
          window.removeEventListener('__GRAVITY_EXEC_CLICK_SUBMIT_RESULT__', handler);
          resolve(false);
        }
      }, 500);
    });
    if (res) return true;
  } catch (_) {}

  // Find candidate submit buttons
  const candidates = Array.from(document.querySelectorAll('button, [role="button"]'));
  let btn = null;

  for (const b of candidates) {
    const label = (b.getAttribute('aria-label') || '').toLowerCase();
    if ((label.includes('generate') || label.includes('create') || label.includes('send') || label.includes('submit')) && !label.includes('download')) {
      btn = b;
      break;
    }
  }

  if (!btn) {
    for (const b of candidates) {
      const svg = b.querySelector('svg, i, span.material-icons, span.google-symbols');
      if (svg) {
        const h = svg.outerHTML.toLowerCase();
        if (h.includes('arrow') || h.includes('send') || h.includes('upward') || h.includes('forward')) {
          btn = b;
          break;
        }
      }
    }
  }

  if (!btn) {
    for (const b of candidates) {
      const txt = (b.textContent || '').trim().toLowerCase();
      if (/^(create|generate|send|run)$/i.test(txt)) {
        btn = b;
        break;
      }
    }
  }

  if (btn) {
    btn.focus();
    btn.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
    btn.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
    btn.click();
    return true;
  }

  // Final fallback: Enter key on the input
  if (inputEl) {
    inputEl.focus();
    inputEl.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    inputEl.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    return true;
  }

  return false;
}

// Token & Project Discovery Helpers
function discoverProjectId() {
  function findUuid(str) {
    if (!str || typeof str !== 'string') return null;
    const m = str.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
    return m ? m[0] : null;
  }
  
  const pm = location.href.match(/project[\\/=]([0-9a-f-]{36})/i);
  if (pm) return pm[1];

  const urlUuid = findUuid(location.href);
  if (urlUuid) return urlUuid;

  try {
    const links = document.querySelectorAll('a[href*="/project/"], a[href*="project="], a[href*="/tools/flow/"]');
    for (const a of links) {
      const u = findUuid(a.href || a.getAttribute('href') || '');
      if (u) return u;
    }
  } catch (e) {}

  try {
    const lastPid = localStorage.getItem('last_flow_project_id') || localStorage.getItem('flow_project_id');
    if (lastPid && findUuid(lastPid)) return findUuid(lastPid);
  } catch (e) {}

  return null;
}

async function fetchSessionToken() {
  try {
    // 1. Check window.__CAPTURED_BEARER_TOKEN__
    if (typeof window !== 'undefined' && window.__CAPTURED_BEARER_TOKEN__) {
      const tok = window.__CAPTURED_BEARER_TOKEN__;
      if (tok.startsWith('ya29.') && tok.length > 30) return tok;
    }

    // 2. Check localStorage
    const savedToken = localStorage.getItem('__gflow_bearer_token');
    const savedTime = Number(localStorage.getItem('__gflow_bearer_time') || 0);
    if (savedToken && savedToken.startsWith('ya29.') && (Date.now() - savedTime < 3000000)) {
      return savedToken;
    }

    // 3. Scan script tags for ya29
    const scripts = document.querySelectorAll('script');
    for (const s of scripts) {
      if (s.textContent && s.textContent.includes('ya29.')) {
        const yaMatch = s.textContent.match(/ya29\.[A-Za-z0-9_-]{30,}/);
        if (yaMatch && yaMatch[0]) return yaMatch[0];
      }
    }
  } catch (e) {}

  return null;
}

async function generateRecaptcha(request) {
  return request.recaptchaToken || null;
}
